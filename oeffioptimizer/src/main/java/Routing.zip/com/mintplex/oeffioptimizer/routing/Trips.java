
package com.mintplex.oeffioptimizer.routing;

import java.util.List;

public class Trips{
   	private Trip trip;

 	public Trip getTrip(){
		return this.trip;
	}
	public void setTrip(Trip trip){
		this.trip = trip;
	}
}
