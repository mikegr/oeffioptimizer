
package com.mintplex.oeffioptimizer.routing;

import java.util.List;

public class Routing{
   	private List<Parameters> parameters;
   	private List<Trips> trips;

 	public List<Parameters> getParameters(){
		return this.parameters;
	}
	public void setParameters(List<Parameters> parameters){
		this.parameters = parameters;
	}
 	public List<Trips> getTrips(){
		return this.trips;
	}
	public void setTrips(List<Trips> trips){
		this.trips = trips;
	}
}
