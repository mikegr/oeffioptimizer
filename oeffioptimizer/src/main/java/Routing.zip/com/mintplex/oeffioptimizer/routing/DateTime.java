
package com.mintplex.oeffioptimizer.routing;

import java.util.List;

public class DateTime{
   	private String date;
   	private String time;

 	public String getDate(){
		return this.date;
	}
	public void setDate(String date){
		this.date = date;
	}
 	public String getTime(){
		return this.time;
	}
	public void setTime(String time){
		this.time = time;
	}
}
