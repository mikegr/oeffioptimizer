
package com.mintplex.oeffioptimizer.routing;

import java.util.List;

public class Interchange{
   	private String desc;
   	private String path;
   	private String type;

 	public String getDesc(){
		return this.desc;
	}
	public void setDesc(String desc){
		this.desc = desc;
	}
 	public String getPath(){
		return this.path;
	}
	public void setPath(String path){
		this.path = path;
	}
 	public String getType(){
		return this.type;
	}
	public void setType(String type){
		this.type = type;
	}
}
